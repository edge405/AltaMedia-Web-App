const express = require('express');
const router = express.Router();
const { 
  saveFormData, 
  getFormData,
  completeForm,
  getAllForms
} = require('../controllers/brandKitController');
const { authenticateToken, requireRole } = require('../middleware/auth');
const { handleMultipleFileUploads, handleMultipleFileUploadsWithGoogleDrive, handleFileUploadError } = require('../middleware/fileUpload');

// Simple validation middleware
const validateRequest = (schema) => {
  return (req, res, next) => {
    // For now, just pass through - we can add validation later
    next();
  };
};

// Test endpoint to verify routes are working
router.get('/test', (req, res) => {
  res.json({
    success: true,
    message: 'BrandKit routes are working!',
    timestamp: new Date().toISOString()
  });
});

/**
 * @route   PUT /api/brandkit/save
 * @desc    Save or update BrandKit form data for a specific step
 * @access  Private
 */
router.put('/save', 
  authenticateToken,
  ...handleMultipleFileUploadsWithGoogleDrive([
    { name: 'reference_materials', maxCount: 10 },
    { name: 'inspiration_links', maxCount: 10 },
    { name: 'website_files', maxCount: 10 }
  ], 'knowing_you_form'),
  handleFileUploadError,
  saveFormData
);

/**
 * @route   GET /api/brandkit/data/:userId
 * @desc    Get BrandKit form data for a user
 * @access  Private
 */
router.get('/data/:userId', 
  authenticateToken,
  getFormData
);

/**
 * @route   PUT /api/brandkit/complete/:userId
 * @desc    Mark BrandKit form as completed
 * @access  Private
 */
router.put('/complete/:userId', 
  authenticateToken,
  completeForm
);

/**
 * @route   GET /api/brandkit/admin/all
 * @desc    Get all BrandKit forms (Admin)
 * @access  Private (Admin)
 */
router.get('/admin/all', 
  authenticateToken,
  requireRole(['admin']),
  getAllForms
);

module.exports = router; 