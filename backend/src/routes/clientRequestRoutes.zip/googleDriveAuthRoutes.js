const express = require('express');
const router = express.Router();
const googleDriveAuth = require('../utils/googleDriveAuth');
const logger = require('../utils/logger');

/**
 * @route GET /api/google-drive/auth-url
 * @desc Get Google Drive authorization URL
 * @access Public (for initial setup)
 */
router.get('/auth-url', (req, res) => {
  try {
    const authUrl = googleDriveAuth.getAuthUrl();
    logger.info('Generated Google Drive authorization URL');
    
    res.json({
      success: true,
      message: 'Authorization URL generated successfully',
      authUrl: authUrl,
      instructions: [
        '1. Visit the authUrl in your browser',
        '2. Sign in to your Google account',
        '3. Grant permissions to the application',
        '4. Copy the authorization code from the callback URL',
        '5. Use the authorization code with the /callback endpoint'
      ]
    });
  } catch (error) {
    logger.error('Failed to generate authorization URL:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to generate authorization URL',
      error: error.message
    });
  }
});

/**
 * @route GET /auth/google/callback
 * @desc Handle Google OAuth2 callback (redirect URI)
 * @access Public (for initial setup)
 */
router.get('/auth/google/callback', async (req, res) => {
  try {
    const { code, error } = req.query;
    
    if (error) {
      logger.error('OAuth2 error:', error);
      return res.status(400).json({
        success: false,
        message: 'OAuth2 authorization failed',
        error: error
      });
    }
    
    if (!code) {
      return res.status(400).json({
        success: false,
        message: 'Authorization code is required'
      });
    }
    
    const tokens = await googleDriveAuth.getTokens(code);
    logger.info('Google Drive tokens obtained successfully');
    
    res.json({
      success: true,
      message: 'Google Drive authentication successful',
      authenticated: googleDriveAuth.isAuthenticated(),
      tokens: {
        access_token: tokens.access_token ? '***' : null,
        refresh_token: tokens.refresh_token ? '***' : null,
        scope: tokens.scope,
        token_type: tokens.token_type,
        expiry_date: tokens.expiry_date
      }
    });
  } catch (error) {
    logger.error('Failed to exchange authorization code:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to exchange authorization code',
      error: error.message
    });
  }
});

/**
 * @route POST /api/google-drive/callback
 * @desc Exchange authorization code for tokens
 * @access Public (for initial setup)
 */
router.post('/callback', async (req, res) => {
  try {
    const { code } = req.body;
    
    if (!code) {
      return res.status(400).json({
        success: false,
        message: 'Authorization code is required'
      });
    }

    const tokens = await googleDriveAuth.getTokens(code);
    
    res.json({
      success: true,
      message: 'Google Drive authentication successful',
      authenticated: googleDriveAuth.isAuthenticated(),
      tokens: {
        access_token: tokens.access_token ? '***' : null,
        refresh_token: tokens.refresh_token ? '***' : null,
        scope: tokens.scope,
        token_type: tokens.token_type,
        expiry_date: tokens.expiry_date
      }
    });
  } catch (error) {
    logger.error('Failed to exchange authorization code:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to exchange authorization code',
      error: error.message
    });
  }
});

/**
 * @route GET /api/google-drive/status
 * @desc Check Google Drive authentication status
 * @access Public (for debugging)
 */
router.get('/status', (req, res) => {
  try {
    const isAuthenticated = googleDriveAuth.isAuthenticated();
    
    res.json({
      success: true,
      authenticated: isAuthenticated,
      message: isAuthenticated ? 'Google Drive is authenticated' : 'Google Drive is not authenticated',
      instructions: isAuthenticated ? 
        'Google Drive is ready to use' : 
        'Please authenticate using /auth-url endpoint first'
    });
  } catch (error) {
    logger.error('Failed to check authentication status:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to check authentication status',
      error: error.message
    });
  }
});

/**
 * @route POST /api/google-drive/refresh
 * @desc Refresh Google Drive access token
 * @access Public (for debugging)
 */
router.post('/refresh', async (req, res) => {
  try {
    const tokens = await googleDriveAuth.refreshToken();
    
    res.json({
      success: true,
      message: 'Google Drive token refreshed successfully',
      authenticated: googleDriveAuth.isAuthenticated(),
      tokens: {
        access_token: tokens.access_token ? '***' : null,
        refresh_token: tokens.refresh_token ? '***' : null,
        scope: tokens.scope,
        token_type: tokens.token_type,
        expiry_date: tokens.expiry_date
      }
    });
  } catch (error) {
    logger.error('Failed to refresh token:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to refresh token',
      error: error.message
    });
  }
});

/**
 * @route GET /api/google-drive/duplicates/:businessName
 * @desc Find duplicate files for a business
 * @access Public (for debugging)
 */
router.get('/duplicates/:businessName', async (req, res) => {
  try {
    const { businessName } = req.params;
    const googleDriveService = require('../utils/googleDrive');
    
    // Set up folder structure to get business folder ID
    const folderStructure = await googleDriveService.setupBusinessFolderStructure(businessName);
    
    // Find duplicate files
    const duplicates = await googleDriveService.findDuplicateFiles(folderStructure.businessFolderId);
    
    res.json({
      success: true,
      message: `Found ${duplicates.length} duplicate file groups for business ${businessName}`,
      businessName: businessName,
      businessFolderId: folderStructure.businessFolderId,
      duplicates: duplicates
    });
  } catch (error) {
    logger.error('Failed to find duplicate files:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to find duplicate files',
      error: error.message
    });
  }
});

/**
 * @route POST /api/google-drive/cleanup/:businessName
 * @desc Clean up duplicate files for a business
 * @access Public (for debugging)
 */
router.post('/cleanup/:businessName', async (req, res) => {
  try {
    const { businessName } = req.params;
    const { dryRun = true } = req.body; // Default to dry run for safety
    const googleDriveService = require('../utils/googleDrive');
    
    // Set up folder structure to get business folder ID
    const folderStructure = await googleDriveService.setupBusinessFolderStructure(businessName);
    
    // Clean up duplicate files
    const results = await googleDriveService.cleanupDuplicateFiles(folderStructure.businessFolderId, dryRun);
    
    res.json({
      success: true,
      message: `Cleanup ${dryRun ? 'simulation' : 'completed'} for business ${businessName}`,
      businessName: businessName,
      businessFolderId: folderStructure.businessFolderId,
      dryRun: dryRun,
      results: results
    });
  } catch (error) {
    logger.error('Failed to cleanup duplicate files:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to cleanup duplicate files',
      error: error.message
    });
  }
});

/**
 * @route GET /api/google-drive/folder-structure/:businessName
 * @desc Get folder structure for a business
 * @access Public (for debugging)
 */
router.get('/folder-structure/:businessName', async (req, res) => {
  try {
    const { businessName } = req.params;
    const googleDriveService = require('../utils/googleDrive');
    
    // Set up folder structure
    const folderStructure = await googleDriveService.setupBusinessFolderStructure(businessName);
    
    res.json({
      success: true,
      message: `Folder structure retrieved for business ${businessName}`,
      businessName: businessName,
      folderStructure: folderStructure
    });
  } catch (error) {
    logger.error('Failed to get folder structure:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get folder structure',
      error: error.message
    });
  }
});

/**
 * @route GET /api/google-drive/business-name/:userId
 * @desc Get business name for a user from database
 * @access Public (for debugging)
 */
router.get('/business-name/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const googleDriveService = require('../utils/googleDrive');
    
    // Get business name for user
    const businessName = await googleDriveService.getBusinessNameForUser(userId);
    
    res.json({
      success: true,
      message: `Business name retrieved for user ${userId}`,
      userId: userId,
      businessName: businessName
    });
  } catch (error) {
    logger.error('Failed to get business name:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get business name',
      error: error.message
    });
  }
});

/**
 * @route GET /api/google-drive/user-folder-structure/:userId
 * @desc Get folder structure for a user (auto-detect business name)
 * @access Public (for debugging)
 */
router.get('/user-folder-structure/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const googleDriveService = require('../utils/googleDrive');
    
    // Get business name for user
    const businessName = await googleDriveService.getBusinessNameForUser(userId);
    
    // Set up folder structure
    const folderStructure = await googleDriveService.setupBusinessFolderStructure(businessName);
    
    res.json({
      success: true,
      message: `Folder structure retrieved for user ${userId}`,
      userId: userId,
      businessName: businessName,
      folderStructure: folderStructure
    });
  } catch (error) {
    logger.error('Failed to get user folder structure:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get user folder structure',
      error: error.message
    });
  }
});

module.exports = router;
