const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middleware/auth');
const {
  getProducts,
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
  getSyncStatus
} = require('../controllers/productController');

// Apply authentication middleware to all routes
router.use(authenticateToken);

/**
 * @route GET /api/products
 * @desc Get all products for the authenticated user
 * @access Private
 */
router.get('/', getProducts);

/**
 * @route GET /api/products/:id
 * @desc Get a single product by ID
 * @access Private
 */
router.get('/:id', getProduct);

/**
 * @route POST /api/products
 * @desc Create a new product
 * @access Private
 */
router.post('/', createProduct);

/**
 * @route PUT /api/products/:id
 * @desc Update a product
 * @access Private
 */
router.put('/:id', updateProduct);

/**
 * @route DELETE /api/products/:id
 * @desc Delete a product
 * @access Private
 */
router.delete('/:id', deleteProduct);

/**
 * @route GET /api/products/:id/sync-status
 * @desc Get sync status for a product
 * @access Private
 */
router.get('/:id/sync-status', getSyncStatus);

module.exports = router;
